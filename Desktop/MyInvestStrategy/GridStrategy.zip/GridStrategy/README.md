## features
- [x] calculate technical indicators, ex: RSI, MACD, Bollinger Bands, Volatility, etc.
- [x] calculate retracement
- [x] calculdate grid buy/sell signals and strategy

## usage
- 1、下载数据
- 2、读取数据
- 3、计算极值、平均值点 KDJ MA BBI RSV PLF等多种指标并展示
- 4、确定策略或者ETF网格是否可以买入
- 5、回测确定目标代码、策略以及收益率

## dependency